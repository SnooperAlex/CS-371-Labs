#ifndef TT_H
#define TT_H
#define MAX_TABLE_SIZE 13
#define MAX_TIMES_TABLE 12

void generateTable(int num, int *table);
void printTable(int num, int *table);
void printTables(int **tables);

#endif