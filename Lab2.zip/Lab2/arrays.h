#ifndef ARRAYS_MEANS
#define ARRAYS_MEANS

double mean(int length, int *arr);
#endif